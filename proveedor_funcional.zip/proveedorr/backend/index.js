const express = require('express');
const app = express();
const mysql = require('mysql2');
const cors = require('cors');

app.use(cors());
app.use(express.json());

// Conexión a la base de datos
const db = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "",
    database: "farmavidav3_"
});

// Crear un proveedor
app.post("/api/proveedores/crear", (req, res) => {
    const { idlaboratorio, nombre, direccion, ciudad, telefono, correo, paginaweb } = req.body;

    if (!idlaboratorio || !nombre || !direccion || !ciudad || !telefono || !correo) {
        return res.status(400).send("Faltan datos obligatorios");
    }

    db.query(
        'INSERT INTO laboratorio (ID_Laboratorio, nombre, direccion, ciudad, telefono, correo_electronico, pagina_web) VALUES (?, ?, ?, ?, ?, ?, ?)',
        [idlaboratorio, nombre, direccion, ciudad, telefono, correo, paginaweb],
        (err, result) => {
            if (err) {
                console.error("Error al insertar en la base de datos:", err);
                return res.status(500).send("Error al registrar el proveedor");
            }
            res.status(200).send("Proveedor registrado con éxito");
        }
    );
});

// Leer proveedores
app.get("/api/proveedores/consul", (req, res) => {
    db.query('SELECT * FROM laboratorio', (err, result) => {
        if (err) {
            console.error("Error al consultar proveedores:", err);
            return res.status(500).send("Error al consultar proveedores");
        }
        res.send(result);
    });
});

// Actualizar un proveedor
app.put("/api/proveedores/actualizar/:idlaboratorio", (req, res) => {
    const { idlaboratorio } = req.params;
    const { nombre, direccion, ciudad, telefono, correo, paginaweb } = req.body;

    db.query(
        'UPDATE laboratorio SET nombre = ?, direccion = ?, ciudad = ?, telefono = ?, correo_electronico = ?, pagina_web = ? WHERE ID_Laboratorio = ?',
        [nombre, direccion, ciudad, telefono, correo, paginaweb, idlaboratorio],
        (err, result) => {
            if (err) {
                console.error("Error al actualizar el proveedor:", err);
                return res.status(500).send("Error al actualizar el proveedor");
            }
            res.status(200).send("Proveedor actualizado con éxito");
        }
    );
});

// Eliminar un proveedor
app.delete("/api/proveedores/eliminar/:idlaboratorio", (req, res) => {
    const { idlaboratorio } = req.params;

    db.query(
        'DELETE FROM laboratorio WHERE ID_Laboratorio = ?',
        [idlaboratorio],
        (err, result) => {
            if (err) {
                console.error("Error al eliminar el proveedor:", err);
                return res.status(500).send("Error al eliminar el proveedor");
            }
            res.status(200).send("Proveedor eliminado con éxito");
        }
    );
});

// Iniciar el servidor
app.listen(3001, () => {
    console.log('Servidor corriendo en http://localhost:3001');
});

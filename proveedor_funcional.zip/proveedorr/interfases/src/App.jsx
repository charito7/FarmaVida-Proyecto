import { useState, useEffect } from 'react';
import './App.css';
import Axios from 'axios';
import 'bootstrap/dist/css/bootstrap.min.css';
import Swal from 'sweetalert2';

function App() {
    // Estados para los campos del formulario
    const [idlaboratorio, setIdLaboratorio] = useState('');
    const [nombre, setNombre] = useState('');
    const [direccion, setDireccion] = useState('');
    const [ciudad, setCiudad] = useState('');
    const [telefono, setTelefono] = useState('');
    const [correo, setCorreo] = useState('');
    const [paginaweb, setPaginaWeb] = useState('');

    const [proveedoresList, setProveedores] = useState([]);

    // Función para registrar un proveedor
    const addProveedor = () => {
        Axios.post("http://localhost:3001/api/proveedores/crear", {
            idlaboratorio,
            nombre,
            direccion,
            ciudad,
            telefono,
            correo,
            paginaweb
        })
            .then(() => {
                Swal.fire('Éxito', 'Proveedor registrado correctamente', 'success');
                getProveedores();
            })
            .catch((error) => {
                console.error("Error al registrar el proveedor:", error);
                Swal.fire('Error', 'No se pudo registrar el proveedor', 'error');
            });
    };

    // Función para obtener proveedores
    const getProveedores = () => {
        Axios.get("http://localhost:3001/api/proveedores/consul")
            .then((response) => {
                setProveedores(response.data);
            })
            .catch((error) => {
                console.error("Error al obtener proveedores:", error);
            });
    };

    // Función para actualizar un proveedor
    const updateProveedor = (idlaboratorio) => {
        Axios.put(`http://localhost:3001/api/proveedores/actualizar/${idlaboratorio}`, {
            nombre,
            direccion,
            ciudad,
            telefono,
            correo,
            paginaweb
        })
            .then(() => {
                Swal.fire('Éxito', 'Proveedor actualizado correctamente', 'success');
                getProveedores();
            })
            .catch((error) => {
                console.error("Error al actualizar el proveedor:", error);
                Swal.fire('Error', 'No se pudo actualizar el proveedor', 'error');
            });
    };

    // Función para eliminar un proveedor
    const deleteProveedor = (idlaboratorio) => {
        Axios.delete(`http://localhost:3001/api/proveedores/eliminar/${idlaboratorio}`)
            .then(() => {
                Swal.fire('Éxito', 'Proveedor eliminado correctamente', 'success');
                getProveedores();
            })
            .catch((error) => {
                console.error("Error al eliminar el proveedor:", error);
                Swal.fire('Error', 'No se pudo eliminar el proveedor', 'error');
            });
    };

    // Obtener proveedores al cargar el componente
    useEffect(() => {
        getProveedores();
    }, []);

    return (
        <div className='App'>
            <form onSubmit={(e) => {
                e.preventDefault();
                addProveedor();
            }}>
                <div className='datos'>
                    <label>ID_Laboratorio: <input type='number' value={idlaboratorio} onChange={(e) => setIdLaboratorio(e.target.value)} /></label>
                    <label>Nombre: <input type='text' value={nombre} onChange={(e) => setNombre(e.target.value)} /></label>
                    <label>Dirección: <input type='text' value={direccion} onChange={(e) => setDireccion(e.target.value)} /></label>
                    <label>Ciudad: <input type='text' value={ciudad} onChange={(e) => setCiudad(e.target.value)} /></label>
                    <label>Teléfono: <input type='tel' value={telefono} onChange={(e) => setTelefono(e.target.value)} /></label>
                    <label>Correo: <input type='email' value={correo} onChange={(e) => setCorreo(e.target.value)} /></label>
                    <label>Página Web: <input type='url' value={paginaweb} onChange={(e) => setPaginaWeb(e.target.value)} /></label>
                    <button type="submit" className="btn btn-primary">Registrar</button>
                </div>
            </form>

            <div className="mt-4">
                <h2>Lista de Proveedores</h2>
                <table className="table table-striped">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Nombre</th>
                            <th>Dirección</th>
                            <th>Ciudad</th>
                            <th>Teléfono</th>
                            <th>Correo</th>
                            <th>Página Web</th>
                            <th>Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        {proveedoresList.map((proveedor) => (
                            <tr key={proveedor.ID_Laboratorio}>
                                <td>{proveedor.ID_Laboratorio}</td>
                                <td>{proveedor.nombre}</td>
                                <td>{proveedor.direccion}</td>
                                <td>{proveedor.ciudad}</td>
                                <td>{proveedor.telefono}</td>
                                <td>{proveedor.correo_electronico}</td>
                                <td>{proveedor.pagina_web}</td>
                                <td>
                                    <button className="btn btn-warning me-2" onClick={() => updateProveedor(proveedor.ID_Laboratorio)}>Actualizar</button>
                                    <button className="btn btn-danger" onClick={() => deleteProveedor(proveedor.ID_Laboratorio)}>Eliminar</button>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        </div>
    );
}

export default App;
